package com.tvm.creditcard.ApplicationProcessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
