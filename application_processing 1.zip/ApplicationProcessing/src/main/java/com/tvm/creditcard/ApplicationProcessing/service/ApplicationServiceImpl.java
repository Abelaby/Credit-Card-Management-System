package com.tvm.creditcard.ApplicationProcessing.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tvm.creditcard.ApplicationProcessing.dao.ApplicationDao;
import com.tvm.creditcard.ApplicationProcessing.entity.CardEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CardIssueEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CustomerEntity;
import com.tvm.creditcard.ApplicationProcessing.enums.CardStatus;
import com.tvm.creditcard.ApplicationProcessing.model.CardDTO;
import com.tvm.creditcard.ApplicationProcessing.model.CardIssueDTO;
import com.tvm.creditcard.ApplicationProcessing.model.CustomerDTO;

import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ApplicationServiceImpl implements ApplicationService {

	private static final long VISA_START = 4000000000000000L;
	private static final long MASTER_START = 500000000000000L;

	private ModelMapper mapper = new ModelMapper();

	@Autowired
	private ApplicationDao appDao;

	@Override
	public CustomerDTO addCustomer(CustomerDTO customer) {
		if (!validateMandatoryFields(customer)) {
			log.error("Missing mandatory Fields");
			return null;
		} else {
			CustomerEntity entity = mapper.map(customer, CustomerEntity.class);
			CustomerEntity respEntity = appDao.addCustomer(entity);
			CustomerDTO dto = mapper.map(respEntity, CustomerDTO.class);
			log.info("Customer Details added");
			generateCardIssueEntry(dto);
			return dto;
		}

	}

	@Override
	public CardDTO addCard(CardDTO card) {
		log.info("In addCard service method", card);
		CardEntity entity = mapper.map(card, CardEntity.class);
		CardEntity respEntity = appDao.addCard(entity);
		CardDTO dto = mapper.map(respEntity, CardDTO.class);
		return dto;
	}

	@Override
	public String getCardExpiry(Integer productExpiry) {
		LocalDate currentDate = LocalDate.now();
		LocalDate futureDate = currentDate.plusMonths(productExpiry);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYMM");
		String formattedDate = futureDate.format(formatter);
		return formattedDate;
	}

	@Override
	public Boolean validateMandatoryFields(CustomerDTO customer) {
		String mobile = customer.getMobile();
		String email = customer.getEmailId();
		String pan = customer.getPan();

		if (StringUtils.isNotBlank(mobile) && StringUtils.isNotBlank(email) && StringUtils.isNotBlank(pan)) {
			return true;
		}
		return false;
	}

	@Override
	public CardDTO generateCard(Integer customerId, Integer productId) {
		// implement logic to get product expiry
		String expiry = getCardExpiry(24);
		Integer cred_limit = 40000;
		Integer per_day_limit = 4000;
		Long cardNumber = generateCardNumber(productId);
		CardDTO card = new CardDTO(customerId, cardNumber, CardStatus.Open.getType(), productId, expiry, cred_limit,
				per_day_limit);
		return card;
	}

	@Override
	public Long generateCardNumber(Integer productId) {
		Long cardNumber = appDao.getLastGeneratedCardNumber(productId);
		if (cardNumber == null) {
			return productId == 1 ? VISA_START : MASTER_START;
		} else {
			return cardNumber = cardNumber + 1;
		}
	}

	@Override
	public CardIssueDTO generateCardIssueEntry(CustomerDTO customer) {
		CardIssueDTO issue = new CardIssueDTO(null, customer.getCustomerId(), customer.getProductId(),
				CardStatus.AwaitingApproval.getType());
		CardIssueEntity entity = mapper.map(issue, CardIssueEntity.class);
		CardIssueEntity respEntity = appDao.addIssueEntry(entity);
		CardIssueDTO dto = mapper.map(respEntity, CardIssueDTO.class);
		return dto;
	}

	@Override
	public String updateIssue(CardIssueDTO issue) {
		if (issue.getIssuerId() == null) {
			log.info("Issue id is mandatory");
			return "Issue id is mandatory";
		}
		System.out.println(issue);
		if (issue.getStatus().equals(CardStatus.Open.getType())) {
			CardIssueEntity cardIssueEntity = appDao.getIssueEntityById(issue.getId());
			cardIssueEntity.setStatus(issue.getStatus());

			@SuppressWarnings("unused")
			CardIssueEntity respEntity = appDao.addIssueEntry(cardIssueEntity);
			log.info("Card approved by Issuer");

			CardDTO card = generateCard(issue.getCustomerId(), issue.getProductId());
			CardDTO cardResp = addCard(card);
			log.info("Card Issued added {}", cardResp.getCardNumber());
			return "Card Issued " + cardResp.getCardNumber();
		} else {
			return "Card Rejected";
		}

	}

	@Override
	public List<CardIssueDTO> getAllIssues() {
		log.info("In getAllStudents service method");
		List<CardIssueEntity> students = appDao.getAllIssues();
		List<CardIssueDTO> dtos = mapper.map(students, new TypeToken<List<CardIssueDTO>>() {
		}.getType());
		return dtos;
	}

}
