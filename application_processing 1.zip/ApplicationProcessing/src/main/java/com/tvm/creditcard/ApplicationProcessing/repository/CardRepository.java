package com.tvm.creditcard.ApplicationProcessing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.tvm.creditcard.ApplicationProcessing.entity.CardEntity;

public interface CardRepository extends JpaRepository<CardEntity, Integer> {

	@Query("SELECT MAX(c.cardNumber) FROM CardEntity c WHERE c.productId = :productId")
	Long findMaxCardNumberByProductId(Integer productId);

}
