package com.tvm.creditcard.ApplicationProcessing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tvm.creditcard.ApplicationProcessing.entity.CustomerEntity;

public interface CustomerRepository extends JpaRepository<CustomerEntity, Integer> {

}
