package com.tvm.creditcard.ApplicationProcessing.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "card")
@AllArgsConstructor
@NoArgsConstructor
public class CardEntity {

	@Id
	@Column(unique = true, nullable = false)
	private Long cardNumber;

	@Column(nullable = false)
	private String customerId;

	private String status;

	@Column(nullable = false)
	private Integer productId;
	private String activatedDate;
	private String expiryDate;
	private Integer creditLimit;
	private Integer perDayLimit;
	private String paymentDueDate;

}
