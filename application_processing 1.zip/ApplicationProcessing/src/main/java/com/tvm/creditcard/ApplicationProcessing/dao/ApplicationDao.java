package com.tvm.creditcard.ApplicationProcessing.dao;

import java.util.List;

import com.tvm.creditcard.ApplicationProcessing.entity.CardEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CardIssueEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CustomerEntity;

public interface ApplicationDao {

	public CustomerEntity addCustomer(CustomerEntity entity);

	public CardEntity addCard(CardEntity entity);

	public Long getLastGeneratedCardNumber(Integer productId);

	public CardIssueEntity addIssueEntry(CardIssueEntity entity);

//	public CardIssueEntity approveOrRejectIssue(CardIssueEntity entity);

	public List<CardIssueEntity> getAllIssues();

	public CardIssueEntity getIssueEntityById(Integer id);

}
