package com.tvm.creditcard.ApplicationProcessing.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "customer")
@AllArgsConstructor
@NoArgsConstructor
public class CustomerEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customerId;

	@Column
	private String name;
	private String dob;
	private String address;

	@Column(nullable = false)
	private String mobile;

	@Column(nullable = false)
	private String pan;

	@Column(nullable = false)
	private String emailId;

	private String createdDate;
	
	private Integer productId;
}
