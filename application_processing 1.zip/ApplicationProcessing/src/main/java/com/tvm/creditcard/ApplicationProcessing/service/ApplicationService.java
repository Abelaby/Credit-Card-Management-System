package com.tvm.creditcard.ApplicationProcessing.service;

import java.util.List;

import com.tvm.creditcard.ApplicationProcessing.model.CardDTO;
import com.tvm.creditcard.ApplicationProcessing.model.CardIssueDTO;
import com.tvm.creditcard.ApplicationProcessing.model.CustomerDTO;

public interface ApplicationService {

	public CustomerDTO addCustomer(CustomerDTO customer);

	public CardDTO addCard(CardDTO card);

	public String getCardExpiry(Integer productExpiry);

	public Boolean validateMandatoryFields(CustomerDTO customer);

	public CardDTO generateCard(Integer customerId, Integer productId);

	public Long generateCardNumber(Integer productId);

	public String updateIssue(CardIssueDTO issue);

	public CardIssueDTO generateCardIssueEntry(CustomerDTO customer);

	public List<CardIssueDTO> getAllIssues();

}
