package com.tvm.creditcard.ApplicationProcessing.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardIssueDTO {
	
	private Integer id;
	private Integer issuerId;
	private Integer customerId;
	private Integer productId;
	private String status;
	public CardIssueDTO(Integer issuerId, Integer customerId, Integer productId, String status) {
		this.issuerId = issuerId;
		this.customerId = customerId;
		this.productId = productId;
		this.status = status;
	}
	
	

}
