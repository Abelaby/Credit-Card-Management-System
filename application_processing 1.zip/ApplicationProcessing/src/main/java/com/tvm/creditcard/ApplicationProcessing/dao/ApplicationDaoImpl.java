package com.tvm.creditcard.ApplicationProcessing.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tvm.creditcard.ApplicationProcessing.entity.CardEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CardIssueEntity;
import com.tvm.creditcard.ApplicationProcessing.entity.CustomerEntity;
import com.tvm.creditcard.ApplicationProcessing.repository.CardIssueRepository;
import com.tvm.creditcard.ApplicationProcessing.repository.CardRepository;
import com.tvm.creditcard.ApplicationProcessing.repository.CustomerRepository;

@Repository
public class ApplicationDaoImpl implements ApplicationDao {

	@Autowired
	private CustomerRepository customerRepo;

	@Autowired
	private CardRepository cardRepo;

	@Autowired
	private CardIssueRepository cardIssueRepo;

	@Override
	public CustomerEntity addCustomer(CustomerEntity entity) {
		return customerRepo.save(entity);
	}

	@Override
	public CardEntity addCard(CardEntity entity) {
		return cardRepo.save(entity);
	}

	@Override
	public Long getLastGeneratedCardNumber(Integer productId) {
		return cardRepo.findMaxCardNumberByProductId(productId);
	}

	@Override
	public CardIssueEntity addIssueEntry(CardIssueEntity entity) {
		return cardIssueRepo.save(entity);
	}

	@Override
	public List<CardIssueEntity> getAllIssues() {
		return cardIssueRepo.findAll();
	}

	@Override
	public CardIssueEntity getIssueEntityById(Integer id) {
		return cardIssueRepo.findById(id).orElseThrow();
	}

}
