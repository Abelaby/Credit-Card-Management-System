package com.tvm.creditcard.ApplicationProcessing.enums;

public enum CardStatus {
	AwaitingApproval("Awaiting Approval"), Open("Open"), Closed("Closed");

	private String type;

	CardStatus(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

}