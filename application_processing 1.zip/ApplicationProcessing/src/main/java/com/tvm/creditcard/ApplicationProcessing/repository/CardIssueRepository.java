package com.tvm.creditcard.ApplicationProcessing.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tvm.creditcard.ApplicationProcessing.entity.CardIssueEntity;

public interface CardIssueRepository extends JpaRepository<CardIssueEntity, Integer> {

}
