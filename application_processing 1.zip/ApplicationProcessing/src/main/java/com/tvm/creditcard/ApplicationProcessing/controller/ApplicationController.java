package com.tvm.creditcard.ApplicationProcessing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tvm.creditcard.ApplicationProcessing.model.CardIssueDTO;
import com.tvm.creditcard.ApplicationProcessing.model.CustomerDTO;
import com.tvm.creditcard.ApplicationProcessing.service.ApplicationService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("customer")
@Slf4j
@CrossOrigin
public class ApplicationController {

	@Autowired
	private ApplicationService appService;

	@PostMapping("/add")
	public CustomerDTO addCustomer(@RequestBody CustomerDTO customer) {
		log.info("in add controller", customer);
		return appService.addCustomer(customer);
	}

	@PostMapping("/updateIssue")
	public String updateIssue(@RequestBody CardIssueDTO issue) {
		log.info("in update issue controller", issue);
		return appService.updateIssue(issue);
	}

	@GetMapping("/getAllIssues")
	public List<CardIssueDTO> getallissue() {
		log.info("in get all issues");
		return appService.getAllIssues();
	}

}
