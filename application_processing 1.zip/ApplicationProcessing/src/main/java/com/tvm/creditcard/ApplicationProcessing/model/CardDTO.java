package com.tvm.creditcard.ApplicationProcessing.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardDTO {

	private Long cardNumber;
	private Integer customerId;
	private String status;
	private Integer productId;
	private String activatedDate;
	private String expiryDate;
	private Integer creditLimit;
	private Integer perDayLimit;
	private String paymentDueDate;
	private String createdDate;

	public CardDTO(Integer customerId, Long cardNumber, String status, Integer id, String expiryDate,
			Integer creditLimit, Integer perDayLimit) {
		this.customerId = customerId;
		this.cardNumber = cardNumber;
		this.status = status;
		this.productId = id;
		this.expiryDate = expiryDate;
		this.creditLimit = creditLimit;
		this.perDayLimit = perDayLimit;
		this.paymentDueDate = LocalDate.now().plusMonths(1).toString();
		this.createdDate = LocalDate.now().toString();
	}
}
