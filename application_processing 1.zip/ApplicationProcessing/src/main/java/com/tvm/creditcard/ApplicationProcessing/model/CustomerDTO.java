package com.tvm.creditcard.ApplicationProcessing.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {

	private Integer customerId;
	private String name;
	private String dob;
	private String address;
	private String mobile;
	private String pan;
	private String emailId;
	private String createdDate;
	private Integer productId;

	public CustomerDTO(String name, String dob, String address, String mobile, String pan, String emailId,
			Integer productId) {
		this.name = name;
		this.dob = dob;
		this.address = address;
		this.mobile = mobile;
		this.pan = pan;
		this.emailId = emailId;
		this.createdDate = LocalDate.now().toString();
		this.productId = productId;
	}

}
