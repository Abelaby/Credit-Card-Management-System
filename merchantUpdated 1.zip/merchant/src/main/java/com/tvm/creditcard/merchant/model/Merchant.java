package com.tvm.creditcard.merchant.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name= "merchant")
public class Merchant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer mId;  //1
    private String name; //2
    private String dob; //3
    private String address; //4

    @Column(nullable = false)
    private long mNumber; //5
    private String panCard; //Alphanumerical //6

    @Column(nullable = false)
    private String email; //7
    private long bankAccNumber; //8
    private String ifscCode; //Alphanumerical //9
    private String bankName; //10
    private String bankLocation; //11
    private MerchantStatus merchantStatus; //12


}
