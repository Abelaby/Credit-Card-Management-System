package com.tvm.creditcard.merchant.controller;


import com.tvm.creditcard.merchant.model.Merchant;
import com.tvm.creditcard.merchant.model.MerchantEnrollRequest;
import com.tvm.creditcard.merchant.service.MerchantServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("merchant")
public class MerchantController {

    @Autowired
    private MerchantServiceImpl merchantService;

//    @GetMapping("merchantExists/{mId}")
//    public boolean checkMerchantExists(@PathVariable Integer mId){
//        return merchantService.checkMIdExists(mId);
//    }
//
//    @GetMapping("merchantIsActive/{mId}")
//    public boolean checkMerchantIsActive(@PathVariable Integer mId){
//        return merchantService.checkMerchantActive(mId);
//    }

    @PostMapping("/register")
    public String registerMerchant(@RequestBody MerchantEnrollRequest merchantEnrollRequest){
        return merchantService.sendMerchantRequest(merchantEnrollRequest);
    }

    @PostMapping("/approveMerchant")
    public String approveMerchant(@RequestBody Integer mId){
        return merchantService.makeMerchantActive(mId);
    }
    
    @GetMapping("/getAllMerchant")
    public List<Merchant> getMerchants(){
    	return merchantService.getAllNonApprovedMerchant();
    }

}
