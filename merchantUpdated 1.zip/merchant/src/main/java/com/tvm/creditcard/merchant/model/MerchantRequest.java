package com.tvm.creditcard.merchant.model;

public class MerchantRequest {
}
