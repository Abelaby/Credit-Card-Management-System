package com.tvm.creditcard.merchant.model;

public enum MerchantStatus {
    CLOSED,
    ACTIVE
}
