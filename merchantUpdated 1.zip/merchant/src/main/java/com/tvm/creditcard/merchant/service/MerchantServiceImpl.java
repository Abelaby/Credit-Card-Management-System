package com.tvm.creditcard.merchant.service;

import com.tvm.creditcard.merchant.model.Merchant;
import com.tvm.creditcard.merchant.model.MerchantEnrollRequest;
import com.tvm.creditcard.merchant.model.MerchantStatus;
import com.tvm.creditcard.merchant.repository.MerchantRepository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MerchantServiceImpl implements MerchantService {

    @Autowired
    private MerchantRepository merchantRepository;


    @Override
    public String sendMerchantRequest(MerchantEnrollRequest merchantRequest) {
        //Map request to object
        Merchant merchant = new Merchant();
        merchant.setAddress(merchantRequest.address()); //1
        merchant.setDob(merchantRequest.dob()); //2
        merchant.setEmail(merchantRequest.email()); //3
        merchant.setMerchantStatus(MerchantStatus.CLOSED);//4 //Request is sent, not approved yet
        merchant.setBankLocation(merchantRequest.bankLocation()); //5
        merchant.setName(merchantRequest.name()); //6
        merchant.setBankLocation(merchantRequest.bankLocation()); //7
        merchant.setBankAccNumber(merchantRequest.bankAccNumber());//8
        merchant.setIfscCode(merchantRequest.ifscCode());//9
        merchant.setBankName(merchantRequest.bankName());//10
        merchant.setMNumber(merchantRequest.mNumber()); //11
        //save object

        merchantRepository.save(merchant);
        Integer merchantId = merchant.getMId();
        return "Merchant registered successfully. Merchant Id is " + merchantId;
    }

    @Override //TODO generate unique merchant code
    public String makeMerchantActive(Integer mId) {
        //get merchant
        Merchant merchant = merchantRepository.findById(mId).orElseThrow();
        merchant.setMerchantStatus(MerchantStatus.ACTIVE);
        merchantRepository.save(merchant);
        return "Merchant is Approved with id: " + mId;

    }

    @Override
    public boolean checkMIdExists(Integer merchantId) {

            return  merchantRepository.existsById(merchantId);
    }

    @Override
    public boolean checkMerchantActive(Integer merchantId) {
        Merchant merchant = merchantRepository.findById(merchantId).orElseThrow();
        if(merchant.getMerchantStatus() == MerchantStatus.ACTIVE){
            return true;
        }
        return false;
    }

    @Override
    public List<Merchant> getAllNonApprovedMerchant() {
        List<Merchant> merchantAll = merchantRepository.findAll();
        List<Merchant> nonApprovedMerchants = new ArrayList<>();  // Initialize the list

        for (Merchant m : merchantAll) {
            if (m.getMerchantStatus() == MerchantStatus.CLOSED) {
                nonApprovedMerchants.add(m);
            }
        }
        return nonApprovedMerchants;
    }


}
