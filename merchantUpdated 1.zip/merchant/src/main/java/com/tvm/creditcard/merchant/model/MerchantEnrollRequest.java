package com.tvm.creditcard.merchant.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record MerchantEnrollRequest( Integer mId,
         String name,
         String dob,
         String address,
         long mNumber,
         String panCard, //Alphanumerical
         String email,
         long bankAccNumber,
         String ifscCode, //Alphanumerical
         String bankName,
         String bankLocation) {
}
