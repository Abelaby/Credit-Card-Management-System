package com.tvm.creditcard.merchant.service;

import java.util.List;

import com.tvm.creditcard.merchant.model.Merchant;
import com.tvm.creditcard.merchant.model.MerchantEnrollRequest;

public interface MerchantService {
    String sendMerchantRequest(MerchantEnrollRequest merchantRequest); //Return mId
    String makeMerchantActive(Integer mId);
    boolean checkMIdExists(Integer merchantId);
    boolean checkMerchantActive(Integer merchantId);
    List<Merchant> getAllNonApprovedMerchant();
}
